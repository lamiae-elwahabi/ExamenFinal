package org.foobarspam.proxyPattern;

public interface DoSomethingSimple<T, R> {
	//Metodos
	public String doRequest(T accion,R objeto);

	

}
