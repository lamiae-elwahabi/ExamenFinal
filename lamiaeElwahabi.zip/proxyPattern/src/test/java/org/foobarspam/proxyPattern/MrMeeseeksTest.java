package org.foobarspam.proxyPattern;

import org.junit.Test;

import junit.framework.TestCase;

public class MrMeeseeksTest extends TestCase {
	
	MrMeeseeks mrMessessks = new MrMeeseeks();
	
	
	@Test
	public void test() {
		assertEquals(3, 3);
	}
}
