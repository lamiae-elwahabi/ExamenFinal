package org.foobarspam.proxyPattern;

public interface Doable extends DoSomethingSimple{

}
